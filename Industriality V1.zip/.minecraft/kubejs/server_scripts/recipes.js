const RecipeOutputToDelete = [
    'mcore:steel_block',
    'mcore:steel_ingot',
    'mcore:steel_nugget',
    'mcore:steel_sheet',
    'mcore:steel_sword',
    'mcore:steel_pickaxe',
    'mcore:steel_axe',
    'mcore:steel_shovel',
    'mcore:steel_hoe',
    'mcore:titanium_sword',
    'mcore:titanium_pickaxe',
    'mcore:titanium_shovel',
    'mcore:titanium_axe',
    'mcore:titanium_hoe',
    'mcore:steel_helmet',
    'mcore:steel_chestplate',
    'mcore:steel_leggings',
    'mcore:steel_boots',
    'mcore:titanium_helmet',
    'mcore:titanium_chestplate',
    'mcore:titanium_leggings',
    'mcore:titanium_boots'
];

ServerEvents.recipes(event => {

    for (let i = 0; i < RecipeOutputToDelete.length; i++) {
        event.remove({output: RecipeOutputToDelete[i]})
    }

    event.shaped(
        Item.of('pointblank:grenade', 1),
        [
          ' A ',
          'BCB',
          ' B '
        ],
        {
          A: 'create:iron_sheet',
          B: 'tfmg:plastic_sheet',
          C: 'minecraft:tnt'
        }
    )

    event.shaped(
        Item.of('pointblank:motor', 1),
        [
          'ABB',
          'CCD',
          'ABB'
        ],
        {
          A: 'tfmg:steel_cogwheel',
          B: 'tfmg:steel_block',
          C: 'tfmg:steel_mechanism',
          D: 'minecraft:netherite_ingot'
        }
    )

    event.replaceInput(
        { input: "mcore:steel_ingot" },
        "mcore:steel_ingot",
        "tfmg:steel_ingot"
    )

    event.replaceInput(
        { input: "mcore:steel_sheet" },
        "mcore:steel_sheet",
        "tfmg:heavy_plate"
    )

    event.remove({ output: 'pointblank:guninternals' })

    event.shaped(
        Item.of('pointblank:guninternals', 1),
        [
          ' AA',
          'ABB'
        ],
        {
          A: 'pointblank:gunmetal_ingot',
          B: 'tfmg:plastic_sheet'
        }
    )

})